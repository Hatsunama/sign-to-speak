#!/usr/bin/env python3
"""Read-only verification of the included corresponding PSL source and resource."""
from pathlib import Path
import gzip, hashlib, json, struct
root=Path(__file__).resolve().parent
source=(root/'sources/public_suffix_list.dat').read_bytes()
lines=source.decode('utf-8').splitlines()
# Mirror PublicSuffixListGenerator.java from OkHttp parent-4.9.2.
selected=[line for line in lines if line.strip() and not line.startswith('//')]
rules=sorted({line.encode('utf-8') for line in selected if not line.startswith('!')})
exceptions=sorted({line[1:].encode('utf-8') for line in selected if line.startswith('!')})
normal=b''.join(line+b'\n' for line in rules)
exception=b''.join(line+b'\n' for line in exceptions)
reconstructed=struct.pack('>I',len(normal))+normal+struct.pack('>I',len(exception))+exception
compressed=(root/'evidence/publicsuffixes.gz').read_bytes()
actual=gzip.decompress(compressed)
assert reconstructed==actual, 'Source does not reproduce the bundled resource payload'
assert hashlib.sha256(compressed).hexdigest()=='a1ef3d0e4ec2cbce14c1884ab0f3a4fef46e258de83530dc562ebb805bdb12fd'
assert len(rules)==8845 and len(exceptions)==8
print(json.dumps({'status':'pass','source_sha256':hashlib.sha256(source).hexdigest(),'compressed_resource_sha256':hashlib.sha256(compressed).hexdigest(),'payload_sha256':hashlib.sha256(actual).hexdigest(),'rules':len(rules),'exception_rules':len(exceptions),'payload_bytes':len(actual)},indent=2))
