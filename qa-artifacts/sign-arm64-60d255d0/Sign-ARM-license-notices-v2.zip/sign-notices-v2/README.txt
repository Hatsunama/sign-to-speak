Sign ARM diagnostic APK: accompanying third-party notices and source

Applies only to Sign-phoneQa-unsigned.apk, SHA-256:
60d255d02a3b44520e024796eda455dd0670af5b3b6aab06aa964dbb9aceaefc

Keep this directory with the APK. See REVIEW.md for the bounded determination,
closure/NOTICES.txt for additional acknowledgements, and
closure/SOURCE_AVAILABILITY.txt for supplied PSL source.

This directory contains no APK, signing keys or application source.
Official third-party source evidence is intentionally retained.
No publication was performed.
