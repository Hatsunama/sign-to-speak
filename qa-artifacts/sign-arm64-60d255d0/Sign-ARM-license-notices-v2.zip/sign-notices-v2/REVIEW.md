# Sign targeted license-closure supplement

2026-10-13. Local review only; no publication, signing, rebuilding or model fetching. The original frozen combined audit is unchanged.

## Result

The previously identified libjpeg notice and PSL corresponding-source gaps are closed by actual versioned texts and supplied corresponding source. Infer, Yoga annotations and Metro mappings are closed with exact-version source evidence. The official libyuv BSD notice and patent grant are now supplied; only the historical CameraX build-to-libyuv revision mapping remains unverified. No conflicting libyuv copyright/license or additional missing permission was identified.

This is a precise source-provenance qualification, not a finding that libyuv lacks redistribution permission. Its official BSD binary terms permit retaining notices in documentation/materials accompanying a binary. We do not represent the current official branch's libyuv pin as the proven pin of the March 2025 CameraX artifact. The historical manifest lookup returned HTTP 401 and was not bypassed.

## Closed evidence

- Fresco 3.6.0 gradle.properties selects libjpeg-turbo 2.1.5.1. The exact tag's LICENSE.md and README.ijg are retained, with their verified Git blob identities. NOTICES.txt supplies the required Independent JPEG Group acknowledgement explicitly. No embedding or APK rebuild is required for these binary-documentation terms.
- The PSL source snapshot is included under MPL-2.0, with the full license and recipient source-availability statement. Its 8,845 rules and 8 exceptions reconstruct every byte of the 104,170-byte decompressed resource. The upstream gzip is byte-identical to the resource in the exact Sign APK. This is corresponding source, not a promise or a moving URL.
- Exact Maven source JARs for infer-annotation 0.18.0 and proguard-annotations 1.19.0 establish matching Facebook MIT copyright in all 35 and 2 Java files respectively. The full applicable MIT notice is supplied.
- Official npm metadata for metro-runtime 0.84.6 identifies gitHead 118de9fdd60fde6a7aa9c0961e65f22492afffcc. Its exact repository LICENSE is retained and hash-verified.

## Flite and first-party application

The complete pinned Flite/SLT notices and modification statement in the combined Sign-only directory may accompany the binary externally. The reviewed terms do not require an in-app notice screen, app rebuild, source publication or a source offer. No separate commercial voice permission requirement was identified. The historical corpus chain was not independently revalidated; that is not evidence of a different license restriction.

Publishing an owner's diagnostic binary does not itself require inventing an open-source license for the first-party application. User authority to publish is separate from this dependency review.

## Boundaries

Use the Sign-only combined directory for any proposed Sign package. Include its notices and PSL source with the APK, preferably in one archive. This supplement is additive; it is not a substitute for React Native, Flite, npm, Maven or native notices retained in the combined directory. No claim is made that the vendor native libraries were rebuilt or every source provenance question has been independently proved.

Unsigned/test-only status, playback/privacy tests, legacy-API playback limits, voice quality and missing recognition features are product or runtime-acceptance matters, not the identified copyright conditions. This audit gives engineering evidence, not a blanket legal warranty. The parent must review and authorize any publication separately.
