# Isolated Flite Android candidate

This is a source-built feasibility candidate, outside the app. It does not select a production voice, perform ASL translation, play audio, initialize JNI or collect user data.

## Provenance and scope

- Official Flite v2.2 commit: `e9e2e37c329dbe98bfeb27a1828ef9a71fa84f88`.
- Approved inventory: `source-manifest.json`, 171 files, exactly 17,696,355 source-body bytes. Manifest SHA-256: `e0969bcb5a34628e66f93517e9cbdb092252988c5920007e18c46f595dc54cd8`.
- Every immutable official source body was checked against its exact byte count and Git blob SHA-1; `source-receipt.json` additionally records SHA-256. Original files under `upstream/` are unchanged. The fetcher rejects redirects before following them and closes redirect bodies without draining; verified bodies are atomically published without replacing existing files. Eight no-network boundary tests cover the actual fetch/redirect/write code with explicit fake HTTP objects.
- Source is the in-tree static `cmu_us_slt` candidate, US English and CMU lexicon. No other voice, downloadable model, corpus or runtime source fetch is included.

## Exact changes

`prepare_sources.py` verifies the original inventory, copies headers, writes ten attributed derivatives and emits `modifications.patch`:

1. `cst_error.h`: guarded status/longjmp in place of process exit.
2. `cst_mlsa.c`: output-size/schema checks, cancellation per frame, request-local noise bit generator, and disabling the legacy `ANDROID` speed hack so the full desktop vocoder order is retained. The new PRNG intentionally changes excitation samples.
3. `cst_tokenstream.c`: rejects any file descriptor during close instead of retaining stdin handling.
4. `cst_synth.c`: cancellation between synthesis modules.
5. `cst_mlpg.c`: cancellation between Cholesky parameter dimensions.
6. `us_text.c`: checked integer-prefix parsing for ranges and fractions, rejecting overflow.
7. `cst_val.c`: checked string-to-int and float-to-int conversions.
8. `cst_string.c`: checked strtod prefix conversion; nonfinite, ERANGE (including underflow) and values beyond FLT_MAX reject. No silent numeric clamping is performed.
9. `cst_cg.c`: duration limit during frame construction and before parameter-matrix allocation.
10. `cst_track.c`: a demonstrated UBSan null-pointer/zero-length memmove is avoided when there are no old frames.

The explicit 90-unit build excludes eight original allocation/error/file/mmap/URL/socket/voice-load/voice-dump units. `private_runtime.c` supplies a C-only guarded wrapper and zeroing allocator. `private_no_io.c` retains required memory formatting and rejects I/O entrypoints without touching their arguments or any external resource. Unneeded remaining functions are discarded by section GC and hidden visibility; final import/export allowlists are checked separately. NDK outlined atomics are disabled on arm64 to remove CPU-property probing. No C++ runtime is linked.

## Boundary and ownership

- One concurrent synthesis; another call returns BUSY. A fresh SLT voice is created within each request arena and no dynamic voice survives its exit.
- Input: 1–256 bytes, printable ASCII English plus whitespace; embedded NUL, other control characters, non-ASCII and whitespace-only input are rejected. The caller retains ownership of its input. The wrapper wipes its own copy.
- Heap: at most 32 MiB of tracked payload and 100,000 allocation records. All tracked allocations, including realloc's old blocks, are zeroed before free. Fatal/cancel rollback does not attempt to destruct partially initialized graphs.
- Output: validated 16 kHz, mono, signed PCM16, at most 480,000 samples (30 seconds). The caller owns the returned PCM and must call `stts_pcm_release`. The output struct must initially be zero. An already-owned output is rejected unchanged.
- Cancellation token must be zero-initialized, modified only through the atomic cancel API while in flight, and remain alive through return. Borrowed input stays immutable while in flight; PCM metadata remains unchanged until release. `stts_cancel` may run on another thread. Only the synthesis thread polls and unwinds. Canceling never frees in-flight state from the requesting thread. A final check occurs after the separate output copy and before publication.
- Cancellation is cooperative; no measured hard maximum cancellation latency is claimed. The eventual app must invalidate stale generations and await its worker before releasing borrowed input/token/output storage.
- Tracked heap and owned buffers are wiped. Upstream stack scratch copies, registers, allocator internals and whole-process memory erasure are not proven.

## Verification performed

- Actual source-built host engine: 487 boundary, failure-recovery, numeric/parser, concurrency/cancellation and ownership assertions, passing both normally and with undefined + float-cast-overflow UBSan. Six allocation-fault positions and a separate output-allocation failure recover. Early in-flight and post-PCM-copy cancellation leave no tracked/unpublished allocations. Real allocator calls exhaust the 32 MiB payload and 100,000-allocation ceilings under explicit test-only hooks. A test-only duration-stretch setting forces the actual duration rejection path; ordinary synthesis succeeds afterward. Valid 256-byte input, fractions/ranges, integer overflow, floating conversion hazards, punctuation and long tokens are exercised. Pathological expansion may return MEMORY before the duration cap; this is an explicit fail-closed resource outcome. The initial test expectation failure and UBSan failure are preserved in source-linked receipts.
- Test-only omitted-wipe negative control fails at the expected wipe-observer trap; the production source variant passes. Test hooks are absent from production binaries.
- Exact production host shared library was exercised twice through its three exported C functions with fixed synthetic text. Both outputs are 43,040 samples, 16 kHz mono PCM16 and have identical SHA-256. No PCM file or playback was created.
- Installed Flite 2.2 SLT gives the same sample count for that phrase, but a different PCM hash. Its embedded-model identity is not verified and the candidate deliberately changes PRNG excitation; compiler/float differences may also apply. This is not parity or naturalness proof.
- Android API 26 arm64-v8a and x86_64 compile/link passes. ELF notes and machine IDs are checked; all LOAD segments align to 16 KiB. Android execution is pending.
- Engine shared-library imports are restricted to memory/string/formatting/math/setjmp and normal NDK CRT/fortify functions. No file/network/audio/logging or ordinary process-exit imports remain. Fortify/stack-protector abort behavior on memory corruption is separate from recovered Flite errors and is retained.

`android_cli_probe.c` is test-only: one self-contained x86_64 PIE executable links the same production engine objects and wrapper. It uses fixed synthetic text, checks empty/pre-cancel behavior, synthesizes to RAM, calculates an explicitly labeled FNV-1a checksum and queries process page size, and wipes/releases its owned buffers. Its sole stdout line contains aggregate schema/count/latency/checksum/owner state. `printf`, monotonic time, `sysconf(_SC_PAGESIZE)` and executable startup imports belong to this harness, not the engine library. No camera, app, JNI, playback, external input, network or PCM file is used. Every probe return goes through owned-text wiping and unexpected-PCM release.

The reviewed host x86_64 reference is 43,040 samples and FNV-1a64 little-endian PCM `0fbbaad2e72e7c99`, repeated identically. `reviewed-evidence.json` binds it to source and host executable hashes. Android Clang/Bionic parity is unproven: any strict-reference mismatch must fail for diagnosis, with no invented tolerance. The successful JSON has exactly status, sample_rate, channels, encoding, samples, pcm_fnv1a64_le, latency_ms, owner_cleared, empty_rejected, pre_canceled_rejected and page_size.

## Reproduction

Toolchain used: NDK `27.1.12297006` (r27b), Clang `18.0.2`, CMake `3.30.5`, bundled Ninja. Host compiler is GCC 14.2.0. Public-safe hashes and results are in `reviewed-evidence.json`; raw build/failure logs remain local. `build_candidate.py` revalidates/regenerates pinned sources before compilation. Source-linked receipts record actual test exits/counts and executable hashes. Staging fails if these receipts are absent, stale, failed or detached from current binaries; four isolated negative cases exercise the real staging script. No passing assertion count is invented by the staging step.

From this source root, with those installed tools:

```sh
python3 prepare_sources.py
CMAKE="${CMAKE:-cmake}" # version 3.30.5
NINJA="${NINJA:-ninja}"
NDK="${ANDROID_NDK_HOME:?Set to NDK 27.1.12297006}"
"$CMAKE" -S . -B build-x86_64 -G Ninja \
  -DCMAKE_MAKE_PROGRAM="$NINJA" -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=x86_64 -DANDROID_PLATFORM=android-26 -DANDROID_STL=none
"$CMAKE" --build build-x86_64 --parallel 2
"$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip" --strip-unneeded \
  -o artifacts/x86_64/private_tts_cli_probe build-x86_64/private_tts_cli_probe
```

For arm64 use `-DANDROID_ABI=arm64-v8a` and a distinct build directory. For host tests use GCC, omit the Android toolchain/options, and run `test_private_tts`; the separately compiled negative executable must terminate with SIGILL and no output. `build_candidate.py` applies two-CPU affinity, a 3 GiB address-space ceiling, core-dump suppression and two build workers. Actual build invocations also hold the shared heavy-job lock and use the parent process/descendant timeout guard. No signing or app packaging takes place.

## Licensing and review gates

`license-audit.json` is the earlier read-only audit, preserved unchanged; its historical authorization status is superseded for this isolated candidate only. It is not legal advice. `artifacts/THIRD_PARTY_NOTICES.txt` preserves root COPYING and all unique upstream C comment blocks, with source paths, rather than dropping less-obvious notices. Original source, authors, disclaimers and change markers are retained; no upstream endorsement is implied. Independent recording/corpus-rights provenance was not fully revalidated. No raw corpus is included.

Before product integration: Android runtime/probe evidence, selected-voice listening evaluation, phone latency/battery measurements, lifecycle/audio-route ownership, any required input-language expansion and release/legal review remain open. The current MediaPipe app min-SDK blocker is independent of this API 26 TTS candidate.
