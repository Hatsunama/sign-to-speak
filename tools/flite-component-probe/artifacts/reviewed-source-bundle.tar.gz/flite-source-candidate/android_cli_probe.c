/* Test harness only. Fixed synthetic text, memory-only PCM, no audio playback.
 * stdout is aggregate probe evidence, not an engine logging API. */
#include "private_tts.h"
#include <inttypes.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

int main(void) {
    uint8_t text[] = "Hello. This is a local speech test.";
    stts_pcm pcm = {0};
    stts_cancel_token canceled = {0};
    struct timespec before = {0}, after = {0};
    int code = 0, nonzero = 0;
    long page_size = sysconf(_SC_PAGESIZE);
    stts_status status = STTS_OK;
    uint64_t checksum = UINT64_C(14695981039346656037);
    size_t count = 0;
    if (page_size != 4096 && page_size != 16384) { code = 8; goto cleanup; }
    stts_cancel(&canceled);
    if (stts_synthesize(text, sizeof(text) - 1, &canceled, &pcm) != STTS_CANCELLED || pcm.samples) {
        code = 2; goto cleanup;
    }
    if (stts_synthesize(text, 0, NULL, &pcm) != STTS_INPUT || pcm.samples) {
        code = 3; goto cleanup;
    }
    if (clock_gettime(CLOCK_MONOTONIC, &before)) { code = 4; goto cleanup; }
    status = stts_synthesize(text, sizeof(text) - 1, NULL, &pcm);
    if (clock_gettime(CLOCK_MONOTONIC, &after)) { code = 4; goto cleanup; }
    if (status != STTS_OK) { code = 5; goto cleanup; }
    if (!pcm.samples || !pcm.count || pcm.count > STTS_MAX_PCM_SAMPLES ||
        pcm.sample_rate != 16000 || pcm.channels != 1) { code = 6; goto cleanup; }
    for (size_t i = 0; i < pcm.count; ++i) {
        uint16_t sample = (uint16_t)pcm.samples[i];
        checksum = (checksum ^ (sample & 255)) * UINT64_C(1099511628211);
        checksum = (checksum ^ (sample >> 8)) * UINT64_C(1099511628211);
        nonzero |= sample != 0;
    }
    count = pcm.count;
    if (!nonzero) code = 7;
cleanup:
    /* Every exit releases unexpected PCM too and wipes this owned text copy. */
    {
        volatile uint8_t *owned = text;
        for (size_t i = 0; i < sizeof(text); ++i) owned[i] = 0;
    }
    stts_pcm_release(&pcm);
    int owner_cleared = !pcm.samples && !pcm.count && !pcm.sample_rate && !pcm.channels;
    if (!owner_cleared) code = 7;
    stts_pcm_release(&pcm);
    if (code) {
        printf("{\"status_code\":%d,\"probe_code\":%d,\"owner_cleared\":%s}\n", status, code, owner_cleared ? "true" : "false");
        return code;
    }
    double milliseconds = (after.tv_sec - before.tv_sec) * 1000.0 +
                          (after.tv_nsec - before.tv_nsec) / 1000000.0;
    printf("{\"status\":\"ok\",\"sample_rate\":16000,\"channels\":1,\"encoding\":\"signed_pcm16\","
           "\"samples\":%zu,\"pcm_fnv1a64_le\":\"%016" PRIx64 "\",\"latency_ms\":%.3f,"
           "\"owner_cleared\":true,\"empty_rejected\":true,\"pre_canceled_rejected\":true,\"page_size\":%ld}\n",
           count, checksum, milliseconds, page_size);
    return 0;
}
