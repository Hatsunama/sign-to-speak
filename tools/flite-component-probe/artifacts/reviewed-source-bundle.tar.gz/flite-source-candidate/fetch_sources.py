"""Fetch only the authorized immutable Flite source manifest, verifying every body."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile
import urllib.request

ROOT = Path(__file__).resolve().parent
MANIFEST = Path('/workspace/shared/sign-core-evidence/flite-v2.2-android-source-proposal.json')
PREFIX = 'https://raw.githubusercontent.com/festvox/flite/e9e2e37c329dbe98bfeb27a1828ef9a71fa84f88/'


class NoRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('Immutable source redirects are forbidden')

    def http_error_302(self, req, fp, code, msg, headers):
        # Do not call the stdlib handler, which drains the body without a bound.
        fp.close()
        raise ValueError('Immutable source redirect rejected before follow')

    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302
    http_error_308 = http_error_302


def verify(entry, body):
    if len(body) != entry['bytes']:
        raise ValueError('Source size mismatch')
    blob = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    if blob != entry['git_blob_sha1']:
        raise ValueError('Source Git blob mismatch')


def existing(path, entry):
    for ancestor in (path, *path.parents):
        if ancestor.is_symlink():
            raise ValueError('Symlink source path')
    if not path.exists():
        return None
    metadata = path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_size != entry['bytes']:
        raise ValueError('Unreviewed existing source')
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0)
    with os.fdopen(os.open(path, flags), 'rb') as stream:
        metadata = os.fstat(stream.fileno())
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_size != entry['bytes']:
            raise ValueError('Existing source changed during open')
        body = stream.read(entry['bytes'] + 1)
    verify(entry, body)
    return body


def fetch(entry, opener=None):
    rel = PurePosixPath(entry['path'])
    if rel.is_absolute() or '..' in rel.parts or entry['source_url'] != PREFIX + str(rel):
        raise ValueError('Source outside approved immutable repository path')
    path = ROOT / 'upstream' / rel
    for ancestor in [path, *path.parents]:
        if ancestor == ROOT.parent:
            break
        if ancestor.is_symlink():
            raise ValueError('Symlink source path')
    body = existing(path, entry)
    if body is None:
        opener = opener or urllib.request.build_opener(NoRedirects())
        with opener.open(entry['source_url'], timeout=45) as response:
            if response.geturl() != entry['source_url']:
                raise ValueError('Unexpected source redirect')
            body = response.read(entry['bytes'] + 1)
    verify(entry, body)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        fd, temporary = tempfile.mkstemp(prefix='.verified-source-', dir=path.parent)
        try:
            with os.fdopen(fd, 'wb') as output:
                output.write(body); output.flush(); os.fsync(output.fileno())
            try:
                # Atomic same-filesystem publication, never overwrite a writer.
                os.link(temporary, path)
            except FileExistsError:
                if existing(path, entry) is None:
                    raise ValueError('Source destination disappeared during publication')
        finally:
            Path(temporary).unlink(missing_ok=True)
    # A writer may have created a destination after the initial cache check.
    # Never return success merely because it now exists.
    if existing(path, entry) is None:
        raise ValueError('Verified source destination missing')
    return {**entry, 'sha256': hashlib.sha256(body).hexdigest()}


def main():
    if hashlib.sha256(MANIFEST.read_bytes()).hexdigest() != 'e0969bcb5a34628e66f93517e9cbdb092252988c5920007e18c46f595dc54cd8':
        raise ValueError('Approved manifest identity changed')
    manifest = json.loads(MANIFEST.read_text())
    files = manifest['files']
    if len(files) != 171 or sum(f['bytes'] for f in files) != 17696355:
        raise ValueError('Approved manifest budget mismatch')
    if len({f['path'] for f in files}) != len(files):
        raise ValueError('Duplicate source paths')
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as workers:
        checked = list(workers.map(fetch, files))
    actual = {p.relative_to(ROOT / 'upstream').as_posix() for p in (ROOT / 'upstream').rglob('*') if p.is_file()}
    if actual != {f['path'] for f in files}:
        raise ValueError('Unexpected source inventory')
    for entry in files:
        if existing(ROOT / 'upstream' / entry['path'], entry) is None:
            raise ValueError('Source missing at final inventory verification')
    receipt = {'status': 'source_verified', 'commit': manifest['commit'], 'file_count': len(checked),
               'source_body_bytes': sum(f['bytes'] for f in checked),
               'manifest_sha256': hashlib.sha256(MANIFEST.read_bytes()).hexdigest(), 'files': checked}
    (ROOT / 'source-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('Verified 171 immutable official source files; 17,696,355 bytes; exact size, Git blob and SHA256 recorded.')


if __name__ == '__main__':
    main()
