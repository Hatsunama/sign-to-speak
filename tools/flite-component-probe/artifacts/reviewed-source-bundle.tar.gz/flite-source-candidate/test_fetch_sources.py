"""No-network tests for immutable redirect rejection and verified atomic writes."""
import hashlib
import json
import io
from pathlib import Path
import tempfile
import types
import unittest
import sys
from unittest.mock import patch
import urllib.request
import fetch_sources as fetcher


class Body(io.BytesIO):
    def __init__(self, body, url):
        super().__init__(body); self.url = url; self.read_sizes = []
    def geturl(self): return self.url
    def read(self, size=-1):
        if size < 0: raise AssertionError('Unbounded response read')
        self.read_sizes.append(size); return super().read(size)


class FetchTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
        self.old_root = fetcher.ROOT; fetcher.ROOT = self.root
        self.body = b'synthetic pinned source\n'
        self.entry = {'path': 'include/test.h', 'bytes': len(self.body),
                      'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(self.body)).encode() + b'\0' + self.body).hexdigest(),
                      'source_url': fetcher.PREFIX + 'include/test.h', 'role': 'header'}
        self.requests = []
    def tearDown(self): fetcher.ROOT = self.old_root; self.temp.cleanup()
    def opener(self, body=None):
        response = Body(self.body if body is None else body, self.entry['source_url'])
        def opening(url, timeout): self.requests.append((url, timeout)); return response
        return types.SimpleNamespace(open=opening), response
    def test_verified_atomic_publication_and_reuse(self):
        opener, response = self.opener(); result = fetcher.fetch(self.entry, opener)
        self.assertEqual((self.root / 'upstream/include/test.h').read_bytes(), self.body)
        self.assertEqual(result['sha256'], hashlib.sha256(self.body).hexdigest())
        self.assertEqual(response.read_sizes, [len(self.body) + 1]); self.assertTrue(response.closed)
        fetcher.fetch(self.entry, types.SimpleNamespace(open=lambda *a, **k: self.fail('Existing source caused network')))
        self.assertEqual(list(self.root.rglob('.verified-source-*')), [])
    def test_redirect_closed_before_follow_or_drain(self):
        handler = fetcher.NoRedirects()
        handler.parent = types.SimpleNamespace(open=lambda *a, **k: self.fail('Redirect followed'))
        for code in (301, 302, 303, 307, 308):
            response = Body(b'x' * 100, self.entry['source_url'])
            with self.assertRaises(ValueError):
                getattr(handler, 'http_error_' + str(code))(urllib.request.Request(self.entry['source_url']), response, code, '', {'Location': 'https://invalid.example/elsewhere'})
            self.assertTrue(response.closed); self.assertEqual(response.read_sizes, [])
    def test_bad_hash_has_no_destination(self):
        opener, _ = self.opener(b'X' * len(self.body))
        with self.assertRaises(ValueError): fetcher.fetch(self.entry, opener)
        self.assertFalse((self.root / 'upstream/include/test.h').exists())
    def test_oversize_read_is_bounded_and_rejected(self):
        opener, response = self.opener(self.body + b'excess')
        with self.assertRaises(ValueError): fetcher.fetch(self.entry, opener)
        self.assertEqual(response.read_sizes, [len(self.body) + 1])
    def test_failed_publication_cleans_temporary(self):
        opener, _ = self.opener()
        with patch.object(fetcher.os, 'link', side_effect=OSError('synthetic publication failure')):
            with self.assertRaises(OSError): fetcher.fetch(self.entry, opener)
        self.assertFalse((self.root / 'upstream/include/test.h').exists())
        self.assertEqual(list(self.root.rglob('.verified-source-*')), [])
    def test_existing_wrong_body_not_overwritten(self):
        path = self.root / 'upstream/include/test.h'; path.parent.mkdir(parents=True); path.write_bytes(b'X' * len(self.body))
        with self.assertRaises(ValueError): fetcher.fetch(self.entry, self.opener()[0])
        self.assertEqual(self.requests, []); self.assertEqual(path.read_bytes(), b'X' * len(self.body))
    def test_symlink_and_wrong_url_rejected(self):
        target = self.root / 'other'; target.mkdir(); (self.root / 'upstream').symlink_to(target, target_is_directory=True)
        with self.assertRaises(ValueError): fetcher.fetch(self.entry, self.opener()[0])
        with self.assertRaises(ValueError): fetcher.fetch({**self.entry, 'source_url': 'https://invalid.example/file'}, self.opener()[0])
        self.assertEqual(self.requests, [])
    def test_destination_appearing_after_preflight_must_be_verified(self):
        path = self.root / 'upstream/include/test.h'
        response = Body(self.body, self.entry['source_url'])
        def opening(url, timeout):
            path.parent.mkdir(parents=True)
            path.write_bytes(b'X' * len(self.body))
            return response
        with self.assertRaises(ValueError): fetcher.fetch(self.entry, types.SimpleNamespace(open=opening))
        self.assertEqual(path.read_bytes(), b'X' * len(self.body))


if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromTestCase(FetchTest))
    root = Path(__file__).resolve().parent
    receipt = {'status': 'passed' if result.wasSuccessful() else 'failed', 'tests_run': result.testsRun,
               'source_sha256': hashlib.sha256((root / 'fetch_sources.py').read_bytes()).hexdigest(),
               'test_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'network_requests': 0, 'boundary': 'actual fetch/redirect/atomic-publish code with explicit fake HTTP opener/body'}
    (root / 'evidence/fetch-tests.json').write_text(json.dumps(receipt, indent=2) + '\n')
    sys.exit(0 if result.wasSuccessful() else 1)
