"""Create a deterministic local source-and-notice bundle. No binary or media upload."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
files = sorted(p for p in ROOT.iterdir() if p.is_file() and p.name not in {'core'})
files += sorted(p for p in (ROOT / 'upstream').rglob('*') if p.is_file())
files += [ROOT / 'artifacts' / name for name in ('THIRD_PARTY_NOTICES.txt', 'MODIFICATIONS.txt')]
# reviewed-evidence.json is the public-safe top-level export. Raw local build
# receipts/logs retain workspace paths and are deliberately not bundled.
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for path in sorted(files):
        data = path.read_bytes()
        name = 'flite-source-candidate/' + path.relative_to(ROOT).as_posix()
        info = tarfile.TarInfo(name)
        info.size = len(data); info.mtime = 0; info.mode = 0o644; info.uid = info.gid = 0
        archive.addfile(info, io.BytesIO(data))
output = ROOT / 'artifacts/flite-android-source-candidate.tar.gz'
with output.open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0, compresslevel=9) as compressed:
        compressed.write(buffer.getvalue())
receipt = {'file': str(output), 'bytes': output.stat().st_size,
           'sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'file_count': len(files),
           'contents': 'Exact 171 upstream source files, local wrapper/tests/build scripts, reviewable patch, pinned manifests, all notices and public-safe reviewed evidence; raw local logs/receipts excluded; no ELF or PCM media',
           'files': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}}
(ROOT / 'evidence/source-bundle.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'files'}, indent=2))
