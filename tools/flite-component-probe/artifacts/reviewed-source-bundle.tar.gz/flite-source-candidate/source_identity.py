"""Identity of all actual compilation inputs and the test/build machinery."""
import hashlib
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(root):
    root = Path(root)
    files = [root / name for name in (
        'CMakeLists.txt', 'exports.map', 'sources.cmake', 'modifications.patch',
        'source-manifest.json', 'prepare_sources.py', 'build_candidate.py', 'source_identity.py')]
    files += sorted(root.glob('*.c')) + sorted(root.glob('*.h'))
    files += sorted(p for p in (root / 'upstream').rglob('*') if p.is_file())
    files += sorted(p for p in (root / 'generated').rglob('*') if p.is_file())
    entries = {p.relative_to(root).as_posix(): digest(p) for p in sorted(files)}
    combined = hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return {'sha256': combined, 'files': entries}
