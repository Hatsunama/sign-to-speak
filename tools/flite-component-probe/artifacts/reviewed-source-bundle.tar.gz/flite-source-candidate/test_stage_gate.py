"""Actual staging-script negative cases against isolated copied evidence fixtures."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
cases = []
with tempfile.TemporaryDirectory(prefix='flite-stage-gate-', dir=ROOT.parent) as directory:
    copy = Path(directory)
    for path in ROOT.iterdir():
        if path.is_file(): shutil.copy2(path, copy / path.name)
    for name in ('upstream', 'generated', 'evidence'):
        shutil.copytree(ROOT / name, copy / name)
    # Immutable binary fixture hard links save disk. Tampering unlinks the local
    # fixture first, so the real candidate cannot be modified through the link.
    for target in ('host', 'host-ubsan', 'arm64-v8a', 'x86_64'):
        dest = copy / ('build-' + target); dest.mkdir()
        names = ['libprivate_tts.so', 'private_tts_cli_probe']
        if target.startswith('host'): names += ['test_private_tts', 'test_private_tts_negative']
        for name in names: os.link(ROOT / ('build-' + target) / name, dest / name)
    def reject(label, expected):
        result = subprocess.run([sys.executable, str(copy / 'stage_artifacts.py')], capture_output=True, text=True, timeout=15)
        if result.returncode == 0 or expected not in result.stderr:
            raise AssertionError('Staging accepted/misdiagnosed synthetic evidence case: ' + label)
        cases.append(label)
    receipt = copy / 'evidence/build-host.json'; original = receipt.read_bytes()
    receipt.unlink(); reject('missing test receipt', 'FileNotFoundError'); receipt.write_bytes(original)
    altered = json.loads(original); altered['tests']['status'] = 'failed'; receipt.write_text(json.dumps(altered))
    reject('failed actual test status', 'Actual host test pass/red control missing'); receipt.write_bytes(original)
    source = copy / 'private_runtime.c'; original_source = source.read_bytes(); source.write_bytes(original_source + b'\n/* synthetic changed source */\n')
    reject('changed source after tests', 'Missing/stale source-linked build evidence'); source.write_bytes(original_source)
    binary = copy / 'build-x86_64/private_tts_cli_probe'; binary.unlink(); binary.write_bytes(b'synthetic wrong executable')
    reject('changed binary after build', 'Untested build output changed')
report = {'status': 'passed', 'cases': cases, 'boundary': 'actual staging script with isolated copied evidence; no builds, network or source mutation',
          'stage_script_sha256': hashlib.sha256((ROOT / 'stage_artifacts.py').read_bytes()).hexdigest(),
          'test_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT / 'evidence/stage-gate-tests.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
