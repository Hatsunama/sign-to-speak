"""Export public-safe verification metadata, omitting workspace paths and raw logs."""
import hashlib
import json
from pathlib import Path
from source_identity import identity, digest

ROOT = Path(__file__).resolve().parent
final = json.loads((ROOT / 'evidence/final-artifacts.json').read_text())
if final['source_identity'] != identity(ROOT):
    raise ValueError('Artifact evidence is stale')
host = json.loads((ROOT / 'evidence/host-cli-reference.json').read_text())
if host['source_identity'] != final['source_identity']['sha256']:
    raise ValueError('Host reference source identity mismatch')
host_build = json.loads((ROOT / 'evidence/build-host.json').read_text())
if host['cli_sha256'] != host_build['binaries']['private_tts_cli_probe']:
    raise ValueError('Host reference executable mismatch')
if host['build_receipt_sha256'] != digest(ROOT / 'evidence/build-host.json'):
    raise ValueError('Host reference build receipt mismatch')
builds = {}
for target in ('host', 'host-ubsan', 'arm64-v8a', 'x86_64'):
    receipt = json.loads((ROOT / 'evidence' / ('build-' + target + '.json')).read_text())
    builds[target] = {key: receipt[key] for key in ('status', 'compiler_sha256', 'runner_sha256', 'binaries', 'tests')}
    builds[target]['source_identity_sha256'] = receipt['source_identity']['sha256']
    builds[target]['receipt_sha256'] = digest(ROOT / 'evidence' / ('build-' + target + '.json'))
public = {
    'status': 'source_review_and_host_tests_passed_android_execution_pending',
    'upstream': {'repository': 'https://github.com/festvox/flite', 'commit': final['source_commit'],
                 'source_file_count': final['source_file_count'], 'source_body_bytes': final['source_body_bytes'],
                 'manifest_sha256': digest(ROOT / 'source-manifest.json')},
    'source_identity': final['source_identity'], 'source_sha256': final['source_sha256'],
    'artifacts': final['artifacts'], 'builds': builds,
    'artifact_transform': 'Build receipts bind unstripped ELF bytes; staged Android artifacts use pinned NDK llvm-strip --strip-unneeded.',
    'host_cli_reference': host, 'fetch_tests': final['fetch_tests'], 'stage_gate_tests': final['stage_gate_tests'],
    'toolchains': {'ndk': final['ndk'], 'cmake': final['cmake'], 'host_gcc': '14.2.0'},
    'scope': {'synthetic_text_only': True, 'pcm_written_to_disk': False, 'audio_playback': False,
              'app_or_jni_initialization': False, 'android_execution_performed': False,
              'ASL_translation_or_natural_voice_quality_validated': False,
              'host_android_bit_parity_proven': False, 'invented_checksum_tolerance': False,
              'whole_process_memory_erasure_proven': False,
              'clean_room_ELF_byte_reproduction_proven': False},
    'rejected_test_cases_retained_locally': ['pathological numeric expansion exceeded allocation budget',
                                          'UBSan found zero-length null memmove, repaired by nonzero-length guard'],
}
encoded = json.dumps(public, indent=2) + '\n'
if '/workspace/' in encoded or '/tmp/' in encoded:
    raise ValueError('Workspace path leaked into public evidence')
(ROOT / 'reviewed-evidence.json').write_text(encoded)
print('Public-safe reviewed-evidence.json SHA256=' + digest(ROOT / 'reviewed-evidence.json'))
