"""Synthetic memory-only comparison; PCM and input buffers are wiped, never saved.

Installed Flite reports version 2.2 and SLT, but its embedded model data identity
has not been matched to this exact source commit. Therefore this is a bounded
format/sample/hash comparison, not reference parity or a naturalness evaluation.
"""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import resource

ROOT = Path(__file__).resolve().parent
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2])
resource.setrlimit(resource.RLIMIT_AS, (3 * 1024**3, 3 * 1024**3))
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
PHRASE = b'Hello. This is a local speech test.'


class Pcm(C.Structure):
    _fields_ = [('samples', C.POINTER(C.c_int16)), ('count', C.c_size_t),
                ('sample_rate', C.c_uint), ('channels', C.c_uint)]


class Wave(C.Structure):
    _fields_ = [('type', C.c_void_p), ('sample_rate', C.c_int), ('num_samples', C.c_int),
                ('num_channels', C.c_int), ('samples', C.POINTER(C.c_int16))]


def describe(samples, count, rate, channels):
    if not samples or not 0 < count <= 16000 * 30 or rate != 16000 or channels != 1:
        raise AssertionError('Unexpected PCM schema')
    # Hash directly over the borrowed native memory; no Python PCM copy retained.
    view = memoryview((C.c_ubyte * (count * 2)).from_address(C.addressof(samples.contents)))
    return {'samples': count, 'sample_rate': rate, 'channels': channels,
            'encoding': 'signed_pcm16', 'pcm_sha256': hashlib.sha256(view).hexdigest()}


candidate_path = ROOT / 'build-host/libprivate_tts.so'
candidate = C.CDLL(str(candidate_path))
candidate.stts_synthesize.argtypes = [C.c_void_p, C.c_size_t, C.c_void_p, C.POINTER(Pcm)]
candidate.stts_synthesize.restype = C.c_int
candidate.stts_pcm_release.argtypes = [C.POINTER(Pcm)]
candidate.stts_pcm_release.restype = None
candidate_results = []
for _ in range(2):
    text = C.create_string_buffer(PHRASE)
    pcm = Pcm()
    try:
        if candidate.stts_synthesize(text, len(PHRASE), None, C.byref(pcm)) != 0:
            raise AssertionError('Candidate synthesis failed')
        candidate_results.append(describe(pcm.samples, pcm.count, pcm.sample_rate, pcm.channels))
    finally:
        C.memset(text, 0, C.sizeof(text))
        candidate.stts_pcm_release(C.byref(pcm))
    if pcm.samples or pcm.count or pcm.sample_rate or pcm.channels:
        raise AssertionError('Candidate output owner was not cleared')
if candidate_results[0] != candidate_results[1]:
    raise AssertionError('Candidate synthetic output not deterministic across requests')

paths = [Path('/usr/lib/x86_64-linux-gnu/' + name + '.so.2.2') for name in
         ('libflite', 'libflite_usenglish', 'libflite_cmulex', 'libflite_cmu_us_slt')]
core = C.CDLL(str(paths[0]), mode=C.RTLD_GLOBAL)
voice_lib = C.CDLL(str(paths[-1]), mode=C.RTLD_GLOBAL)
core.flite_init.restype = C.c_int
core.flite_text_to_wave.argtypes = [C.c_char_p, C.c_void_p]
core.flite_text_to_wave.restype = C.POINTER(Wave)
core.delete_wave.argtypes = [C.POINTER(Wave)]
core.delete_wave.restype = None
voice_lib.register_cmu_us_slt.argtypes = [C.c_char_p]
voice_lib.register_cmu_us_slt.restype = C.c_void_p
voice_lib.unregister_cmu_us_slt.argtypes = [C.c_void_p]
voice_lib.unregister_cmu_us_slt.restype = None
if core.flite_init() != 0:
    raise AssertionError('Installed engine initialization failed')
voice = voice_lib.register_cmu_us_slt(None)
if not voice:
    raise AssertionError('Installed voice initialization failed')
text = C.create_string_buffer(PHRASE)
wave = None
try:
    wave = core.flite_text_to_wave(text, voice)
    if not wave:
        raise AssertionError('Installed synthesis failed')
    installed_result = describe(wave.contents.samples, wave.contents.num_samples,
                                wave.contents.sample_rate, wave.contents.num_channels)
finally:
    C.memset(text, 0, C.sizeof(text))
    if wave:
        C.memset(wave.contents.samples, 0, wave.contents.num_samples * wave.contents.num_channels * 2)
        core.delete_wave(wave)
    voice_lib.unregister_cmu_us_slt(voice)
report = {
    'synthetic_input_id': 'local-speech-test-phrase-v1',
    'candidate': candidate_results, 'installed_flite_2_2_slt': installed_result,
    'candidate_binary_sha256': hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
    'installed_binaries': [{'file': p.name, 'bytes': p.stat().st_size,
                            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],
    'same_embedded_model_identity_verified': False,
    'sample_count_equal': candidate_results[0]['samples'] == installed_result['samples'],
    'pcm_hash_equal': candidate_results[0]['pcm_sha256'] == installed_result['pcm_sha256'],
    'differences': 'Candidate intentionally replaces libc random excitation with per-request xorshift32. Compiler/float differences and unverified installed model identity also preclude hash-parity expectations.',
    'audio_playback': False, 'pcm_saved': False, 'android_runtime_exercised': False,
    'natural_voice_quality_evaluated': False,
}
(ROOT / 'evidence/pcm-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ('installed_binaries',)}, indent=2))
