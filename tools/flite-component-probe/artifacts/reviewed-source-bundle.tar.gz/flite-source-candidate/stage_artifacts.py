"""Strip and verify local Android candidates; no upload, installation or execution."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from source_identity import identity, digest

ROOT = Path(__file__).resolve().parent
BIN = Path('/workspace/shared/android-test-tools/sdk/ndk/27.1.12297006/toolchains/llvm/prebuilt/linux-x86_64/bin')
OUT = ROOT / 'artifacts'
OUT.mkdir(exist_ok=True)
ALLOWED = set('''__cxa_atexit __cxa_finalize __memcpy_chk __register_atfork __stack_chk_fail
__strchr_chk __errno calloc exp free log longjmp malloc memcpy memmove memset pow setjmp
strchr strcmp strcpy strlen strncmp strncpy strrchr strtod vsprintf'''.split())
EXPORTS = {'stts_synthesize', 'stts_cancel', 'stts_pcm_release'}
report = []
fetch_tests = json.loads((ROOT / 'evidence/fetch-tests.json').read_text())
if (fetch_tests['status'] != 'passed' or fetch_tests['tests_run'] <= 0 or
        fetch_tests['source_sha256'] != digest(ROOT / 'fetch_sources.py') or
        fetch_tests['test_sha256'] != digest(ROOT / 'test_fetch_sources.py')):
    raise ValueError('Missing/stale fetch boundary test evidence')
current_identity = identity(ROOT)
builds = {}
for target in ('host', 'host-ubsan', 'arm64-v8a', 'x86_64'):
    path = ROOT / 'evidence' / ('build-' + target + '.json')
    result = json.loads(path.read_text())
    if result['status'] != 'passed' or result['source_identity'] != current_identity:
        raise ValueError('Missing/stale source-linked build evidence: ' + target)
    if result['runner_sha256'] != digest(ROOT / 'build_candidate.py'):
        raise ValueError('Stale build/test runner evidence')
    for name, expected in result['binaries'].items():
        if digest(ROOT / ('build-' + target) / name) != expected:
            raise ValueError('Untested build output changed: ' + target + '/' + name)
    if target.startswith('host'):
        tests = result['tests']
        if tests['status'] != 'passed' or tests['assertions'] <= 0 or tests['negative_exit'] != -4:
            raise ValueError('Actual host test pass/red control missing')
        for field, name in [('test_executable_sha256', 'test_private_tts'),
                            ('negative_executable_sha256', 'test_private_tts_negative')]:
            if digest(ROOT / ('build-' + target) / name) != tests[field]:
                raise ValueError('Test executable changed after execution')
        if tests['positive_stderr'] or tests['negative_stdout_bytes'] or tests['negative_stderr_bytes']:
            raise ValueError('Unexpected test/sanitizer output')
        if target == 'host-ubsan' and tests['sanitizers'] != ['undefined', 'float-cast-overflow']:
            raise ValueError('Required UBSan coverage missing')
    builds[target] = result
stage_tests = json.loads((ROOT / 'evidence/stage-gate-tests.json').read_text())
if (stage_tests['status'] != 'passed' or
        stage_tests['stage_script_sha256'] != digest(Path(__file__)) or
        stage_tests['test_script_sha256'] != digest(ROOT / 'test_stage_gate.py')):
    raise ValueError('Missing/stale artifact staging gate tests')


def run(*args):
    return subprocess.check_output(list(map(str, args)), text=True)


def symbols(path, mode):
    output = run(BIN / 'llvm-nm', '-D', mode, path)
    return {line.split()[-1].split('@')[0] for line in output.splitlines() if line.strip()}, output


for abi in ('arm64-v8a', 'x86_64'):
    targets = [('libprivate_tts.so', False)]
    if abi == 'x86_64':
        targets.append(('private_tts_cli_probe', True))
    for name, probe in targets:
        source = ROOT / ('build-' + abi) / name
        dest = OUT / abi / name
        dest.parent.mkdir(exist_ok=True)
        subprocess.run([str(BIN / 'llvm-strip'), '--strip-unneeded', '-o', str(dest), str(source)], check=True)
        imports, import_text = symbols(dest, '--undefined-only')
        exports, export_text = symbols(dest, '--defined-only')
        # Executable CRT and harness additionally use startup, aggregate stdout
        # and monotonic timing; these are absent from the engine-only artifact.
        allowed = ALLOWED | ({'__libc_init', 'printf', 'clock_gettime', 'sysconf'} if probe else set())
        if imports - allowed:
            raise ValueError('Unexpected imports: ' + str(imports - allowed))
        if not probe and exports != EXPORTS:
            raise ValueError('Unexpected engine exports: ' + str(exports))
        headers = run(BIN / 'llvm-readelf', '-h', '-lW', '-n', dest)
        loads = [line.split() for line in headers.splitlines() if line.strip().startswith('LOAD ')]
        if not loads or any(int(row[-1], 16) < 0x4000 for row in loads):
            raise ValueError('Missing 16 KiB load alignment')
        if 'description data: 1a 00 00 00 ' not in headers:
            raise ValueError('Android API 26 ELF identity note missing')
        expected_machine = 'AArch64' if abi == 'arm64-v8a' else 'Advanced Micro Devices X86-64'
        if expected_machine not in headers:
            raise ValueError('ABI mismatch')
        (ROOT / 'evidence' / (abi + '-' + name + '-elf.txt')).write_text(headers + '\nIMPORTS\n' + import_text + '\nEXPORTS\n' + export_text)
        report.append({'abi': abi, 'file': str(dest.relative_to(ROOT)), 'bytes': dest.stat().st_size,
                       'sha256': hashlib.sha256(dest.read_bytes()).hexdigest(), 'android_api_note': 26,
                       'load_segment_alignment': [int(row[-1], 16) for row in loads],
                       'imports': sorted(imports), 'exports': sorted(exports),
                       'test_only_cli': probe, 'android_execution': False})

manifest = ROOT / 'source-manifest.json'
ledger = ROOT / 'license-audit.json'
if not manifest.exists():
    shutil.copyfile('/workspace/shared/sign-core-evidence/flite-v2.2-android-source-proposal.json', manifest)
if not ledger.exists():
    shutil.copyfile('/workspace/shared/sign-core-evidence/flite-v2.2-android-license-audit.json', ledger)
# Preserve all source comment blocks rather than guessing which are legal
# notices. Identical blocks are grouped, with every applicable path recorded.
comments = {}
for entry in json.loads((ROOT / 'source-receipt.json').read_text())['files']:
    path = entry['path']
    if path.endswith(('.c', '.h')):
        for block in re.findall(r'/\*.*?\*/', (ROOT / 'upstream' / path).read_text(), flags=re.S):
            comments.setdefault(block, set()).add(path)
notices = (ROOT / 'upstream/COPYING').read_text() + '\n\nPRESERVED UPSTREAM COMMENT/NOTICE BLOCKS\n'
for block, paths in comments.items():
    notices += '\nFiles: ' + ', '.join(sorted(paths)) + '\n' + block + '\n'
(OUT / 'THIRD_PARTY_NOTICES.txt').write_text(notices)
(OUT / 'MODIFICATIONS.txt').write_text(
    'Isolated source-built candidate from Flite e9e2e37c329dbe98bfeb27a1828ef9a71fa84f88. '
    'Upstream source files remain byte-identical. Generated derivatives and local wrapper are described '
    'in modifications.patch, prepare_sources.py, private_runtime.c and README.md. '
    'No endorsement by upstream authors is implied.\n')
files = ['private_tts.h', 'private_runtime.h', 'private_runtime.c', 'private_no_io.c',
         'test_private_tts.c', 'android_cli_probe.c', 'CMakeLists.txt', 'exports.map', 'sources.cmake',
         'fetch_sources.py', 'prepare_sources.py', 'build_candidate.py', 'compare_pcm.py',
         'stage_artifacts.py', 'source_identity.py', 'test_fetch_sources.py', 'test_stage_gate.py',
         'modifications.patch', 'source-manifest.json', 'license-audit.json', 'README.md',
         'artifacts/THIRD_PARTY_NOTICES.txt', 'artifacts/MODIFICATIONS.txt']
receipt = {'status': 'compiled_and_host_tested_android_runtime_pending', 'artifacts': report,
           'source_sha256': {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in files},
           'source_commit': 'e9e2e37c329dbe98bfeb27a1828ef9a71fa84f88',
           'source_file_count': 171, 'source_body_bytes': 17696355,
           'ndk': '27.1.12297006 (r27b), Clang 18.0.2', 'cmake': '3.30.5',
           'source_identity': current_identity,
           'build_receipt_sha256': {target: digest(ROOT / 'evidence' / ('build-' + target + '.json')) for target in builds},
           'host_tests': builds['host']['tests'], 'ubsan_tests': builds['host-ubsan']['tests'],
           'fetch_tests': fetch_tests,
           'stage_gate_tests': stage_tests,
           'no_playback': True, 'no_pcm_files': True, 'no_app_or_jni_initialization': True,
           'not_validated': ['Android execution', 'voice naturalness', 'ASL translation',
                             'full process-memory erasure', 'phone latency/battery', 'app lifecycle integration']}
(ROOT / 'evidence/final-artifacts.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(report, indent=2))
