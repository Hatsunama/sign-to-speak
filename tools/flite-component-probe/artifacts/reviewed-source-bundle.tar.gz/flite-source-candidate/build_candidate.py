"""Bounded-job payload; caller must hold the shared heavy-job lock and guard."""
import argparse
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import re
import sys
from source_identity import identity, digest

ROOT = Path(__file__).resolve().parent
TOOLS = Path('/workspace/shared/android-test-tools')
CMAKE = TOOLS / 'sdk/cmake/3.30.5/bin/cmake'
NINJA = TOOLS / 'sdk/cmake/3.30.5/bin/ninja'
NDK = TOOLS / 'sdk/ndk/27.1.12297006'
parser = argparse.ArgumentParser()
parser.add_argument('--target', choices=['host', 'host-ubsan', 'arm64-v8a', 'x86_64'], required=True)
args = parser.parse_args()
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2])
resource.setrlimit(resource.RLIMIT_AS, (3 * 1024**3, 3 * 1024**3))
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
build = ROOT / ('build-' + args.target)
receipt_path = ROOT / 'evidence' / ('build-' + args.target + '.json')
receipt_path.unlink(missing_ok=True)
# Verify original pinned bodies and regenerate derivatives before any compile.
subprocess.run([sys.executable, str(ROOT / 'prepare_sources.py')], check=True)
source = identity(ROOT)
configure = [str(CMAKE), '-S', str(ROOT), '-B', str(build), '-G', 'Ninja',
             '-DCMAKE_MAKE_PROGRAM=' + str(NINJA), '-DCMAKE_BUILD_TYPE=Release']
if args.target.startswith('host'):
    configure += ['-DCMAKE_C_COMPILER=/usr/bin/gcc']
    if args.target == 'host-ubsan':
        sanitizer = '-fsanitize=undefined,float-cast-overflow -fno-sanitize-recover=all'
        configure += ['-DCMAKE_C_FLAGS=' + sanitizer, '-DCMAKE_EXE_LINKER_FLAGS=' + sanitizer,
                      '-DCMAKE_SHARED_LINKER_FLAGS=' + sanitizer]
else:
    configure += ['-DCMAKE_TOOLCHAIN_FILE=' + str(NDK / 'build/cmake/android.toolchain.cmake'),
                  '-DANDROID_ABI=' + args.target, '-DANDROID_PLATFORM=android-26',
                  '-DANDROID_STL=none']
subprocess.run(configure, check=True)
subprocess.run([str(CMAKE), '--build', str(build), '--parallel', '2'], check=True)
tests = None
if args.target.startswith('host'):
    negative = subprocess.run([str(build / 'test_private_tts_negative')], timeout=60, capture_output=True)
    if negative.returncode != -signal.SIGILL or negative.stdout or negative.stderr:
        raise RuntimeError('Red control did not reach the expected wipe-verification trap')
    print('RED control: omitted-wipe variant failed as expected, exit=' + str(negative.returncode), flush=True)
    positive = subprocess.run([str(build / 'test_private_tts')], timeout=60,
                              capture_output=True, text=True)
    (ROOT / 'evidence' / (args.target + '-tests.stdout')).write_text(positive.stdout)
    (ROOT / 'evidence' / (args.target + '-tests.stderr')).write_text(positive.stderr)
    if positive.returncode:
        failure_data = json.dumps(
            {'status': 'failed', 'source_identity': source, 'exit': positive.returncode,
             'test_executable_sha256': digest(build / 'test_private_tts'),
             'stdout': positive.stdout, 'stderr': positive.stderr}, indent=2) + '\n'
        (ROOT / 'evidence' / (args.target + '-failure-' + source['sha256'][:12] + '.json')).write_text(failure_data)
        (ROOT / 'evidence' / (args.target + '-failure.json')).write_text(failure_data)
        raise RuntimeError('Actual test failed: ' + positive.stderr)
    print(positive.stdout, end='', flush=True)
    if positive.stderr:
        raise RuntimeError('Unexpected test/sanitizer stderr: ' + positive.stderr)
    match = re.search(r'^PASS: (\d+) boundary/recovery/ownership assertions;', positive.stdout)
    if not match:
        raise RuntimeError('Missing actual test completion')
    tests = {'status': 'passed', 'assertions': int(match.group(1)),
             'positive_stdout': positive.stdout, 'positive_stderr': positive.stderr,
             'negative_exit': negative.returncode, 'negative_stdout_bytes': len(negative.stdout),
             'negative_stderr_bytes': len(negative.stderr),
             'test_executable_sha256': digest(build / 'test_private_tts'),
             'negative_executable_sha256': digest(build / 'test_private_tts_negative'),
             'sanitizers': ['undefined', 'float-cast-overflow'] if args.target == 'host-ubsan' else []}
if identity(ROOT) != source:
    raise RuntimeError('Source changed during build/test')
receipt = {'status': 'passed', 'target': args.target, 'source_identity': source,
           'configure_command': configure, 'tests': tests,
           'compiler_sha256': digest(Path('/usr/bin/gcc') if args.target.startswith('host') else NDK / 'toolchains/llvm/prebuilt/linux-x86_64/bin/clang'),
           'binaries': {name: digest(build / name) for name in ('libprivate_tts.so', 'private_tts_cli_probe')},
           'runner_sha256': digest(Path(__file__))}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
